function cg = cgfunc(A)

  disp(A);



end

